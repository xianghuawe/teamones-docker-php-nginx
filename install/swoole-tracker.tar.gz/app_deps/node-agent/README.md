安装
-----
* swoole 4.3.5 或更高版本

运行
----
```shell
cd path/node-agent
sudo php bin/node.php
```